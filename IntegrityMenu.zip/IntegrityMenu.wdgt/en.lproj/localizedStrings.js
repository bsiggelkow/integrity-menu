var localizedStrings = new Object;

localizedStrings["Hello, World!"] = "Hello, World!";
localizedStrings["Done"] = "Done";
